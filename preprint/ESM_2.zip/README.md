# Online Resource 2 — numerical supporting information

Article: Historical abstract loss and use-dependent robustness of a semantic novelty indicator. Scientometrics submission candidate. Yunya Lin, School of Information Sciences, University of Illinois Urbana-Champaign, Champaign, IL, USA. Correspondence: yoyolin2@illinois.edu.

All 56 numerical data/identifier files retain their rc.2 bytes and full precision. Original results and separately labelled post hoc summaries remain distinct; no new inference or scientific computation is introduced by this package.

## Data and code availability

Online Resource 2 contains original and revision-stage derived numerical summaries, identifier projections and saved cutoff/loss-membership records. Complete scalar vectors and their verifier are public in verification/scalar_scores of release v1.1.1; focal-neighbor records remain private. Source texts, embeddings, model weights and licensed literature are excluded. Grants cover only the explicitly mapped author-controlled files, not third-party inputs. The original and revision-stage analysis, tests, reporting and figure-generation code are archived as version 1.1.1 in Zenodo (Lin, 2026) (https://doi.org/10.5281/zenodo.23298679) and the corresponding GitHub release (https://github.com/YoyoLin008/historical-abstract-loss-semantic-novelty/releases/tag/v1.1.1). The immutable version 1.0.0 archive (https://doi.org/10.5281/zenodo.23222368) predates the revision additions. The supplied reporting routes and saved-membership checks were freshly verified; independent scalar-to-endpoint reconstruction passed on the actual public v1.1.1 download. Complete source acquisition and encoder reconstruction remain incomplete. Supplementary Sections S8 and S13.6 distinguish these layers.

The public software scope is distinct from this journal numerical resource. Reporting reconstruction, saved-ID membership proof, complete masked-scalar endpoint reconstruction, saved-embedding scoring and full fresh acquisition/encoding are separate levels. The public scalar package supports scalar-to-endpoint reconstruction; it does not supply fresh acquisition/encoding. Source texts, embeddings, weights, licensed literature, private audits and correspondence are not included.

## Reading the files

Use UTF-8 CSV/JSON/JSONL; keep identifiers as strings. Original and revision dictionaries give units, denominators, undefined values and field definitions. Source A/B use historical strata in intensity summaries and focal-source counts where explicitly specified in neighbor summaries. Selected loss uses each source's fixed baseline-selected count. Assignment SD/percentiles are not inferential confidence intervals. Empty conditional bins remain undefined. SHA256SUMS hashes every other payload. The software results map identifies current executable reporting commands; this ZIP itself contains numerical evidence, not those scripts.

The historical provenance/manifest snapshots describe their dated generation state; their older null publication fields are not current availability claims. Current access is stated above and in docs/revision_provenance.json. No claim of journal submission, acceptance or full raw-to-encoder reproduction is made.

## Coordinated final revision

The policy_comparison folder supplies the completed post hoc comparison for Supplementary S14. The current public scalar/preprint archive is v1.1.1, DOI 10.5281/zenodo.23298679; it does not contain the removal comparison. The 37 scalar files are public; detailed focal-neighbor records remain excluded. See policy_comparison/README.md for exact verification and access scope.
